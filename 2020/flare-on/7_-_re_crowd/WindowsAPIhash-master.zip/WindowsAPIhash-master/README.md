# WindowsAPIhash
Windows API Hashes used in the malwares

https://hiddencodes.wordpress.com/2014/08/22/windows-api-hash-list-1/
https://hiddencodes.wordpress.com/2014/08/22/windows-api-hash-list-2/
https://hiddencodes.wordpress.com/2014/11/07/api-hash-list-3/
https://hiddencodes.wordpress.com/2014/11/11/api-hash-list-4/
https://hiddencodes.wordpress.com/2014/11/30/api-hash-list-5/
https://hiddencodes.wordpress.com/2014/09/18/windows-process-name-hashes-list-1/
